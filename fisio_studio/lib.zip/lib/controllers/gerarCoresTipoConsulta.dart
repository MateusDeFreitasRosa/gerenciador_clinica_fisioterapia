import 'dart:math';
import 'package:flutter/cupertino.dart';

Color gerarCores() {
  dynamic rnd = Random();
  dynamic r = rnd.nextInt(16) * 16;
  dynamic g = rnd.nextInt(16) * 16;
  dynamic b = rnd.nextInt(16) * 16;
  Color color = Color.fromARGB(255, r, g, b);
  return color;
}
