class DataPaciente {
  final String name;
  final String adress;
  final String birthDate;
  final String phone;
  final String cpf;

  DataPaciente(this.name, this.adress, this.birthDate, this.phone, this.cpf,);
}