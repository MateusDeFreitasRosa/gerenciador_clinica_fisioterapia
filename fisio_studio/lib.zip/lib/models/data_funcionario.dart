class DataFuncionario {
  final String name;
  final String adress;
  final String birthDate;
  final String phone;
  final String cpf;
  final String job;
  final int previlegio;

  DataFuncionario(this.name, this.adress, this.birthDate, this.phone, this.cpf,
      this.job, this.previlegio);
}
