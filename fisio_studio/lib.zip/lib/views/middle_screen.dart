import 'package:flutter/material.dart';

class MiddleScreen extends StatefulWidget {
  const MiddleScreen({ Key? key }) : super(key: key);

  @override
  _MiddleScreenState createState() => _MiddleScreenState();
}

class _MiddleScreenState extends State<MiddleScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}