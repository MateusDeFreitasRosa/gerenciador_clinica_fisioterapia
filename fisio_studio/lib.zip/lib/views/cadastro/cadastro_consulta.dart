import 'package:fisio_studio/widgets/custom_buttom.dart';
import 'package:fisio_studio/widgets/custom_textfield.dart';
import 'package:flutter/material.dart';
import 'package:time_range_picker/time_range_picker.dart';

class CadastroConsulta extends StatefulWidget {
  final DateTime dateTime;
  const CadastroConsulta({Key? key, required this.dateTime}) : super(key: key);

  @override
  _CadastroConsultaState createState() => _CadastroConsultaState();
}

class _CadastroConsultaState extends State<CadastroConsulta> {
  late TimeOfDay timeOfDayStart;
  late TimeOfDay timeOfDayEnd;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    print('Horário pego: ${widget.dateTime}');
    timeOfDayStart =
        TimeOfDay(hour: widget.dateTime.hour, minute: widget.dateTime.minute);

    timeOfDayEnd = TimeOfDay(
        hour: widget.dateTime.hour + 1, minute: widget.dateTime.minute);
  }

  void setTimePicker() async {
    TimeRange timeRange = await showTimeRangePicker(
      context: context,
      start: timeOfDayStart,
      end: timeOfDayEnd,
    );
    print("result " + timeRange.toString());
    setState(() {
      timeOfDayStart = timeRange.startTime;
      timeOfDayEnd = timeRange.endTime;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  constraints: const BoxConstraints(maxWidth: 400),
                  padding: const EdgeInsets.all(20),
                  decoration: const BoxDecoration(
                    color: Colors.black26,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.shade800,
                            borderRadius: BorderRadius.circular(10)),
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        padding: const EdgeInsets.all(5),
                        child: Text(
                          '${widget.dateTime.day}/${widget.dateTime.month}/${widget.dateTime.year}',
                          style: TextStyle(color: Colors.white, fontSize: 18),
                        ),
                      ),
                      Material(
                          color: Colors.transparent,
                          elevation: 5,
                          child: InkWell(
                            onTap: () {
                              setTimePicker();
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.grey.shade800,
                                  borderRadius: BorderRadius.circular(10)),
                              margin: const EdgeInsets.symmetric(vertical: 10),
                              padding: const EdgeInsets.all(5),
                              child: Text(
                                'Horário de entrada: ${timeOfDayStart.hour} : ${timeOfDayStart.minute}',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          )),
                      Material(
                        color: Colors.transparent,
                        elevation: 5,
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.grey.shade800,
                              borderRadius: BorderRadius.circular(10)),
                          margin: const EdgeInsets.symmetric(vertical: 10),
                          padding: const EdgeInsets.all(5),
                          child: Text(
                            'Horário de saída: ${timeOfDayEnd.hour} : ${timeOfDayEnd.minute}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        child: CustomTextFiled(
                          hintText: 'CPF Paciente',
                          icon: const Icon(
                            Icons.person,
                            color: Colors.white,
                          ),
                          onChanged: () {},
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        child: CustomTextFiled(
                          hintText: 'CPF Profissional',
                          icon: const Icon(
                            Icons.person,
                            color: Colors.white,
                          ),
                          onChanged: () {},
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomButtom(
                            label: 'Cadastrar',
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
